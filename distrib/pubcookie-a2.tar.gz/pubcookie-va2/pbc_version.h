/*
    $Id: pbc_version.h,v 1.6 1999/01/23 04:18:00 willey Exp $
 */

#ifndef PUBCOOKIE_VERSION
#define PUBCOOKIE_VERSION

#define PBC_VERSION "a2"

#endif /* !PUBCOOKIE_VERSION */
