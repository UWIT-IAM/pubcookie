/*
    $Id: pbc_version.h,v 1.7 1999/02/10 19:52:23 willey Exp $
 */

#ifndef PUBCOOKIE_VERSION
#define PUBCOOKIE_VERSION

#define PBC_VERSION "a3"

#endif /* !PUBCOOKIE_VERSION */
