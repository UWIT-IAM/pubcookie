/*
    $Id: pbc_version.h,v 1.12 1999/07/22 22:50:16 willey Exp $
 */

#ifndef PUBCOOKIE_VERSION
#define PUBCOOKIE_VERSION

#define PBC_VERSION "a5"
#define PBC_TESTID "release2"

#endif /* !PUBCOOKIE_VERSION */
