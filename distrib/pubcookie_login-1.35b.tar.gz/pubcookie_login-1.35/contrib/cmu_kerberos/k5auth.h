const char *kerberos5_verify_password(const char *user,
				      const char *passwd,
				      const char *principal,
				      char *path_to_srvtab);
