/*
    $Id: pbc_version.h,v 1.11 1999/07/08 22:53:05 willey Exp $
 */

#ifndef PUBCOOKIE_VERSION
#define PUBCOOKIE_VERSION

#define PBC_VERSION "a5"
#define PBC_TESTID "release1"

#endif /* !PUBCOOKIE_VERSION */
