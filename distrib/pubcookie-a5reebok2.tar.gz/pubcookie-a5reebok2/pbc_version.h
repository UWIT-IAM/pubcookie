/*
    $Id: pbc_version.h,v 1.10 1999/06/25 22:14:33 willey Exp $
 */

#ifndef PUBCOOKIE_VERSION
#define PUBCOOKIE_VERSION

#define PBC_VERSION "a5"
#define PBC_TESTID "rebook2"

#endif /* !PUBCOOKIE_VERSION */
