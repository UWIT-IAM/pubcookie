/*
    $Id: pbc_version.h,v 1.9 1999/05/26 18:00:24 willey Exp $
 */

#ifndef PUBCOOKIE_VERSION
#define PUBCOOKIE_VERSION

#define PBC_VERSION "a4"
#define PBC_TESTID "reebok1"

#endif /* !PUBCOOKIE_VERSION */
