/*
    $Id: pbc_version.h,v 1.8 1999/02/12 02:00:53 willey Exp $
 */

#ifndef PUBCOOKIE_VERSION
#define PUBCOOKIE_VERSION

#define PBC_VERSION "a4"

#endif /* !PUBCOOKIE_VERSION */
