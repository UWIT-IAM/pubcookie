/*
    $Id: pbc_version.h,v 1.13 1999/07/23 18:27:23 willey Exp $
 */

#ifndef PUBCOOKIE_VERSION
#define PUBCOOKIE_VERSION

#define PBC_VERSION "a5"
#define PBC_TESTID "release3"

#endif /* !PUBCOOKIE_VERSION */
